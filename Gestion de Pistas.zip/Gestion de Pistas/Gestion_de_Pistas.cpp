#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>  
#define MAX_PISTAS 100

char *pistas[MAX_PISTAS];   
int longitudes[MAX_PISTAS]; 
int num_pistas = 0;        
int opcion; 
int longitud;  
int num_pista, num_tramo;  
char estado;  

void menuPrincipal();         
void esperarEnter();          
void mostrarPistas();         
void cambiarEstadoTramo();    
void agregarPista();          
void eliminarPista();         
void liberarMemoria();        
void limpiarPantalla();      

// Funcion principal que muestra el menu y gestiona las opciones
void menuPrincipal() {
    do {
        limpiarPantalla(); 
        printf("\n--- Gestion de Pistas de Aterrizaje ---\n");
        printf("1. Mostrar estado de todas las pistas\n");
        printf("2. Cambiar estado de un tramo\n");
        printf("3. Agregar una nueva pista\n");
        printf("4. Eliminar una pista existente\n");
        printf("5. Salir\n");
        printf("Seleccione una opcion: ");
        
        // Lee la opcion
        if (scanf("%d", &opcion) != 1) {
            printf("Entrada no valida.\n");  
            opcion = 0;  
            while (getchar() != '\n');  
        }

        // Casos de cada funcion 
        switch (opcion) {
            case 1: mostrarPistas(); break;          
            case 2: cambiarEstadoTramo(); break;     
            case 3: agregarPista(); break;           
            case 4: eliminarPista(); break;       
            case 5: liberarMemoria(); printf("Saliendo del programa...\n"); break; 
            default: printf("Opcion no valida.\n"); break;  
        }
        
        if (opcion != 5) {
            esperarEnter();
        }
    } while (opcion != 5);  
}

// Funcion para esperar el enter
void esperarEnter() {
    int ch;
    while ((ch = getchar()) != '\n' && ch != EOF);  
    printf("Presione Enter para continuar...\n");  
    getchar();  
}

// Funcion para agregar una nueva pista
void agregarPista() {
    printf("Ingrese la longitud de la nueva pista (numero de tramos): ");
    if (scanf("%d", &longitud) != 1 || longitud <= 0) {
        printf("Longitud invalida.\n"); 
        return;  
    }

    // Asignar memoria para la nueva pista
    pistas[num_pistas] = (char *)malloc(longitud * sizeof(char));
    if (pistas[num_pistas] == NULL) {
        printf("Error al asignar memoria.\n");  
        return; 
    }

    // Muestra la pista como libre 
    for (int i = 0; i < longitud; i++) {
        pistas[num_pistas][i] = 'L';
    }

    // Guarda el tama�o de la pista y aumenta el contador de pistas
    longitudes[num_pistas] = longitud;
    num_pistas++;
    printf("Pista agregada exitosamente.\n"); 
}

// Funcion para mostrar el estado de todas las pistas
void mostrarPistas() {
    if (num_pistas == 0) {
        printf("No hay pistas registradas.\n");  
        return;  
    }
    // Muestra las pistas
    for (int i = 0; i < num_pistas; i++) {
        printf("Pista %d: ", i + 1);
        for (int j = 0; j < longitudes[i]; j++) {
            printf("%c ", pistas[i][j]); 
        }
        printf("\n");  
    }
}

// Funcion que cambia el estado de un tramo
void cambiarEstadoTramo() {
    printf("Ingrese numero de pista (1 a %d): ", num_pistas);
    if (scanf("%d", &num_pista) != 1) {
        printf("Entrada no valida.\n"); 
        return; 
    }
    num_pista--;  // Ajuste para que la pista empiece en 1
    
    if (num_pista < 0 || num_pista >= num_pistas) {
        printf("Pista no valida.\n");
        return;  
    }

    printf("Ingrese numero de tramo (1 a %d): ", longitudes[num_pista]);
    if (scanf("%d", &num_tramo) != 1) {
        printf("Entrada no valida.\n");  
        return; 
    }
    num_tramo--;  // Ajuste para que el tramo empiece en 1
    
    
    if (num_tramo < 0 || num_tramo >= longitudes[num_pista]) {
        printf("Tramo no valido.\n");
        return; 
    }

    printf("Ingrese nuevo estado (L = Libre, O = Ocupado, M = Mantenimiento): ");
    scanf(" %c", &estado);  
    estado = toupper(estado);  

   
    if (estado != 'L' && estado != 'O' && estado != 'M') {
        printf("Estado no valido.\n");
        return;  
    }

    // Actualiza el estado del tramo
    pistas[num_pista][num_tramo] = estado;
    printf("Estado actualizado.\n");  
}

// Funci�n para eliminar una pista
void eliminarPista() {
    printf("Ingrese el numero de pista a eliminar (1 a %d): ", num_pistas);
    if (scanf("%d", &num_pista) != 1 || num_pista < 1 || num_pista > num_pistas) {
        printf("Numero de pista invalido.\n"); 
        return;  
    }

    num_pista--;  
    free(pistas[num_pista]);  // Libera el espacio de la memoria de las pistas borradas

    for (int i = num_pista; i < num_pistas - 1; i++) {
        pistas[i] = pistas[i + 1];
        longitudes[i] = longitudes[i + 1];
    }

    num_pistas--;  
    printf("Pista eliminada exitosamente.\n"); 
}

// Funciones para liberar memoria y limpiar la pantalla
void liberarMemoria() {
    for (int i = 0; i < num_pistas; i++) {
        free(pistas[i]);  // Liberar cada pista
    }
}
void limpiarPantalla() {
    system("cls");  
}

// int main del programa :o
int main() {
    menuPrincipal(); 
    printf("Programa finalizado. Presione Enter para salir...\n");
    esperarEnter();  
    return 0;  
}

